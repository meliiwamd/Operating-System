#include "types.h"
#include "user.h"
#include "stat.h"

int main(void){
	
	int firstP = getpid();
    //This is the test file
    for(int i = 0; i < 19; i++){
        
        //We want to have some processes
        int child = fork();
        if(child == 0){
            //Child process
            //malloc memory a bit!

            int* memory = (int*)malloc(sizeof(int) * 100);
        }
        //Parent does nothing
    }
    wait();
    if(firstP == getpid()){
    	struct proc_info* answer = (struct proc_info*)malloc(sizeof(struct proc_info) * 64);
    	getInfo(&answer);
    }
    exit();
}
